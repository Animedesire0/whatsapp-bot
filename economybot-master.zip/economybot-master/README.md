# Economy Bot
### Using Quick.db & Discord.js (V11)

## THIS WAS ORIGINALLY CODED FOR DJS V11 SO IT WILL NOT PROPERLY WORK ON V12 UNLESS YOU UPDATE IT

##### This was a quick personal project (Following a Youtube tutorial) but never ended up fully finishing (cleaning up code, proper checks etc) and felt like this may help people.
##### A star is always appreciated. I am not updating this anymore.
##### If you have an issue with Quick.db Or Discord.js Go to one of these links:

+ [Quick.db Repo](https://github.com/TrueXPixels/quick.db)
+ [Quick.db Discord](https://discordapp.com/invite/plexidev)
+ [Discord.js Discord](https://discordapp.com/invite/bRCvFy9)
